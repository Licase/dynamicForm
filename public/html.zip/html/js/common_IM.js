        (function() {


            if (window.location.protocol.indexOf('http') != -1) {
                window.localStorage["rootUrl"] = window.location.protocol + '//' + window.location.host;
            } else {
                window.localStorage["rootUrl"] = '/';
            }

            $.fn.getUrlData = function() {
                    var url = location.search;
                    var theRequest = new Object();
                    if (url.indexOf("?") != -1) {
                        var str = url.substr(1);
                        var strs = str.split("&");
                        for (var i = 0; i < strs.length; i++) {
                            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                        }
                    }
                    return theRequest;
                }
                /**
                 * 时间戳转换时�? 
                 * 调用方式$().htmlFontSize({
                 * time:null, //10位时间戳或�?13位时间戳 不输入为当前时间
                 * style:'yyyy-MM-dd hh-mm-ss' //输出样式
                 * });
                 */
            $.fn.getTime = function(a) {
                    this._default = {
                        time: null,
                        style: 'yyyy-MM-dd hh-mm-ss'
                    }
                    $.extend(this._default, a);
                    if (this._default.time) {
                        var time = this._default.time;
                        var len = time.toString().length
                        if (len == 10) {
                            var timestamp3 = time * 1000;
                        } else if (len == 13) {
                            var timestamp3 = time;
                        }
                    } else {
                        var timestamp3 = (new Date()).valueOf();
                    }
                    var newDate = new Date();
                    newDate.setTime(timestamp3);
                    Date.prototype.format = function(format) {
                        var date = {
                            "M+": this.getMonth() + 1,
                            "d+": this.getDate(),
                            "h+": this.getHours(),
                            "m+": this.getMinutes(),
                            "s+": this.getSeconds(),
                            "q+": Math.floor((this.getMonth() + 3) / 3),
                            "S+": this.getMilliseconds()
                        };
                        if (/(y+)/i.test(format)) {
                            format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
                        }
                        for (var k in date) {
                            if (new RegExp("(" + k + ")").test(format)) {
                                format = format.replace(RegExp.$1, RegExp.$1.length == 1 ?
                                    date[k] : ("00" + date[k]).substr(("" + date[k]).length));
                            }
                        }
                        return format;
                    }
                    return newDate.format(this._default.style);
                }
                /**
                 * 封�?�ajax 
                 *   调用方式
                 *   param {
                 *      url: 'index.php',
                 *      type: 'get',
                 *      data: {}
                 *   }
                 *   $().mkAjax(param).then(function(data){}).fail(function(err){});
                 */
            $.fn.mkAjax = function(param) {
                    var _this = this;
                    _this._default = {
                        url: 'index.php',
                        type: 'get',
                        data: {}
                    }
                    $.extend(_this._default, param);
                    var _url = window.localStorage['rootUrl'] + _this._default.url;
                    var dtd = $.Deferred();
                    var header = {};
                    console.log(_this._default);
                    // var token = localStorage.getItem('token');
                    // if (token) {
                    //     var type = this._default.type.toLocaleUpperCase();
                    //     var timestamp = Date.parse(new Date());
                    //     var hashkey = type + "," + this._default.url + ",{" + timestamp + "}";
                    //     var sha256 = CryptoJS.HmacSHA256(hashkey, token).toString();
                    //     var word = CryptoJS.enc.Utf8.parse(sha256);
                    //     var auth = CryptoJS.enc.Base64.stringify(word);
                    //     var author = 'Token token=\"' + token + '\",' + 'timestamp=\"' + timestamp + '\",auth=\"' + auth + '\"';
                    header = {

                        // "Content-Type":"Application/JSON; charset=GBK"
                    };
                    // }

                    $.ajax({
                        url: _url,
                        type: _this._default.type,
                        data: _this._default.data,
                        timeout: 3000,

                        headers: header,
                        success: function(res) {

                            dtd.resolve(res, _this._default.data);

                        },
                        error: function(err) {

                            dtd.reject(err);
                        }
                    });
                    return dtd.promise();
                }
                // ��ʼ������
            $.fn.initSetting = function(settingArgu) {
                if (settingArgu) {
                    var setting = settingArgu;
                } else {
                    setting = window.parent.setting;
                }
                console.log(setting)

                Array.prototype.forEach.call(document.querySelectorAll(".layui-word-aux"), function(el, index) {
                    if (el.tagName == "INPUT") {
                        if (el.type == "text") {
                            el.value = setting[el.getAttribute("id")];
                        } else if (el.type == "checkbox") {
                            if (setting[el.getAttribute("name")] == "1") {
                                el.checked = true;
                            }
                        } else if (el.type == "radio") {
                            if (setting[el.getAttribute("name")] == el.value) {
                                el.checked = true;
                            }
                        }
                    } else if (el.tagName == "SMALL") {
                        el.html(setting[el.getAttribute("id")]);
                    } else if (el.tagName == "SPAN") {
                        el.html(setting[el.getAttribute("id")]);
                    } else if (el.tagName == "BUTTON") {
                        el.html(setting[el.getAttribute("id")]);
                    }
                });
            }

            /*-----------------------��������---------------------*/
            function reload() {
                window.location.reload();
            }

            $('.saveClick').click(function() {

                var changeIpArr = {
                        AREA_NUM: $('#AREA_NUM').val(),
                        netIp: toIP('#reviseNetIp input'),
                        netSubnetMask: toIP('#reviseNetSubnetMask input'),
                        SERVERIP: toIP('#reviseSERVERIP input'),
                        port: $('#port').val(),
                    },
                    changeIpFlag = false;
                var templateArr = {
                        TITLE: GBKTourl($('#TITLE').val()),
                        SUB_TITLE: GBKTourl($('#SUB_TITLE').val()),
                        LB_QUEUE_TIME: $('#LB_QUEUE_TIME button').html(),
                        STYLE: $('#STYLE button').html()
                    },
                    templateFlag = false;
                var alarmSetupArr = {
                        SPEED_FASTER: colorBtnSave($('#SPEED_FASTER button').html()),
                        SPEED_SLOWER: colorBtnSave($('#SPEED_SLOWER button').html()),
                        INFUSION_FINISH: colorBtnSave($('#INFUSION_FINISH button').html()),
                        SIGNAL_WEAK: colorBtnSave($('#SIGNAL_WEAK button').html()),
                        BATTERY_WEAK: colorBtnSave($('#BATTERY_WEAK button').html()),
                        INFUSION_ING: colorBtnSave($('#INFUSION_ING button').html()),
                        INFUSION_WILL: colorBtnSave($('#INFUSION_WILL button').html())
                    },
                    alarmSetupFlag = false;
                var safeArr = {
                        oldPassword: $('#oldPassword').val(),
                        newPassword: $('#newPassword').val(),
                        againPassword: $('#againPassword').val()
                    },
                    safeFlag = false;

                for (obj in changeIpArr) { //�������
                    if (changeIpArr[obj].indexOf('error') >= 0 || (obj == 'port' && changeIpArr[obj].replace(/\s+/g,
                            "") == '')) { //��֤��ͨ��
                        if (changeIpArr['port'].replace(/\s+/g, "") == '') {
                            $('#port').css('border', '1px solid red');
                        }
                        goChange();
                        return
                    }
                    if (changeIpArr[obj] != setting[obj]) {
                        changeIpFlag = true;
                        break
                    }
                }
                for (obj in templateArr) {
                    if (templateArr[obj] != setting[obj]) {
                        templateFlag = true;
                        break
                    }
                }
                for (obj in alarmSetupArr) {
                    if (alarmSetupArr[obj] != setting[obj]) {
                        alarmSetupFlag = true;
                        break
                    }
                }
                if (safeArr.oldPassword.replace(/\s+/g, "") != '' && safeArr.againPassword.replace(/\s+/g, "") != '' &&
                    safeArr.newPassword.replace(/\s+/g, "") != '') {
                    safeFlag = true
                } else if ((safeArr.oldPassword.replace(/\s+/g, "") + safeArr.againPassword.replace(/\s+/g, "") +
                        safeArr.newPassword.replace(/\s+/g, "")).length > 0) {
                    for (var i in safeArr) {
                        if ($('#' + i).val().replace(/\s+/g, "") == '') {
                            $('#' + i).css('border', '1px solid red');
                        }
                    }
                    //    $('.layui-nav-item a').eq(6).trigger("click");
                    $('.layui-nav a')[10].click()
                    return


                }
                var restartArr = [],
                    reloadArr = [];
                $('.saveClick').attr('disabled', true)
                if (changeIpFlag) {
                    console.log('��ַ�����޸���', changeIpArr);
                    restartArr.push(changeIpFlag)
                    $().mkAjax({ //�ο�����Ľӿ�
                        url: '/LB_FORM',
                        type: 'POST',
                        data: {
                            AREA_NUM: changeIpArr.AREA_NUM,
                            HTTPSERVERPORT: changeIpArr.port,
                            IF0IPADDRESS: changeIpArr.netIp,
                            IF0IPNETMASK: changeIpArr.netSubnetMask,
                            SERVERIP: changeIpArr.SERVERIP,
                            NETWORK_CHANGED: 'YES',
                            CODE_CHANGED: 'YES'
                        }
                    }).then(function(res) {
                        restartArr.shift();
                    }).fail(function(err) {


                    })

                }
                if (templateFlag) {
                    reloadArr.push(templateFlag)
                    $().mkAjax({ //�ο�����Ľӿ�
                        url: '/LB_DC_INFO',
                        type: 'POST',
                        data: {
                            QUICK_REQUEST: templateArr.QUICK_REQUEST,
                            TITLE: templateArr.TITLE,
                            SUB_TITLE: templateArr.SUB_TITLE,
                            LB_QUEUE_TIME: templateArr.LB_QUEUE_TIME,
                            STYLE: templateArr.STYLE
                        }
                    }).then(function(res) {
                        reloadArr.shift()
                    }).fail(function(err) {

                    })


                }
                if (SHOW_FIELDSFlag) {
                    reloadArr.push(SHOW_FIELDSFlag)
                    var SHOW_FIELDSArr = {},
                        SHOW_FIELDS = '';

                    var len = choosed.length;
                    SHOW_FIELDSArr.QUICK_REQUEST = "advancedSetup";
                    if (len == 0) {
                        SHOW_FIELDS = 'null'
                    } else {
                        for (var k = 0; k < len; k++) {
                            SHOW_FIELDS += choosed[k].field_identify + ',';
                        }
                        SHOW_FIELDS = SHOW_FIELDS.substring(0, SHOW_FIELDS.length - 1);
                        SHOW_FIELDSArr.SHOW_FIELDS = SHOW_FIELDS;
                        for (var i = 0; i < len; i++) {
                            var val = "";
                            var jLen = choosed[i].setting.length;
                            for (var j = 0; j < jLen; j++) {

                                choosed[i].setting[j].nick = encodeURIComponent(choosed[i].setting[j].nick);
                                choosed[i].setting[j].value = encodeURIComponent(choosed[i].setting[j].value);
                                val += choosed[i].setting[j].value + ',';
                            }
                            val = val.substring(0, val.length - 1)
                            SHOW_FIELDSArr[choosed[i].field_identify] = {};
                            SHOW_FIELDSArr[choosed[i].field_identify].name = encodeURIComponent(choosed[i].name);
                            SHOW_FIELDSArr[choosed[i].field_identify].nick = encodeURIComponent(choosed[i].nick);
                            SHOW_FIELDSArr[choosed[i].field_identify].bg = choosed[i].bg;
                            SHOW_FIELDSArr[choosed[i].field_identify].font = choosed[i].font;
                            SHOW_FIELDSArr[choosed[i].field_identify].border = choosed[i].border;
                            SHOW_FIELDSArr[choosed[i].field_identify].size = choosed[i].size;
                            SHOW_FIELDSArr[choosed[i].field_identify].val = val;
                            SHOW_FIELDSArr[choosed[i].field_identify].setting = choosed[i].setting;
                            SHOW_FIELDSArr[choosed[i].field_identify] = JSON.stringify(SHOW_FIELDSArr[choosed[i]
                                .field_identify]);
                        }
                    }
                    $().mkAjax({ //�ο�����Ľӿ�
                        url: '/LB_DC_INFO',
                        type: 'POST',
                        data: SHOW_FIELDSArr
                    }).then(function(res) {
                        reloadArr.shift()
                    }).fail(function(err) {


                    })
                }
                if (alarmSetupFlag) {
                    reloadArr.push(alarmSetupFlag)
                    $().mkAjax({ //�ο�����Ľӿ�
                        url: '/LB_DC_INFO',
                        type: 'POST',
                        data: {
                            QUICK_REQUEST: 'AlarmInfo',
                            SPEED_FASTER: alarmSetupArr.SPEED_FASTER, // ��Һ����
                            SPEED_SLOWER: alarmSetupArr.SPEED_SLOWER, // ��Һ����
                            INFUSION_FINISH: alarmSetupArr.INFUSION_FINISH, // ��Һ���
                            SIGNAL_WEAK: alarmSetupArr.SIGNAL_WEAK, // ���ź�
                            BATTERY_WEAK: alarmSetupArr.BATTERY_WEAK, // �޵���
                            INFUSION_ING: alarmSetupArr.INFUSION_ING, // ��Һ��
                            INFUSION_WILL: alarmSetupArr.INFUSION_WILL // ����

                        }
                    }).then(function(res) {
                        reloadArr.shift()
                    }).fail(function(err) {

                    })

                }
                if (safeFlag) {

                    if (safeArr.newPassword != safeArr.againPassword) {
                        alert('�������벻һ��')
                        $('.saveClick').attr('disabled', false);
                        return
                    }
                    restartArr.push(safeFlag)
                    $().mkAjax({
                        url: "/LB_FORM",
                        type: 'post',
                        data: {
                            ".ACCOUNT": 'admin',
                            OLDPASSWORD: safeArr.oldPassword,
                            NEWPASSWORD: safeArr.againPassword
                        }
                    }).then(function(res) {
                        $().mkAjax({
                            url: "/lb_pwd_state.htm",
                            type: 'get',
                            data: {}
                        }).then(function(res) {

                            if (res == 's') {
                                restartArr.shift()
                            } else {
                                alert('����ʧ��')
                                $('.saveClick').attr('disabled', false);
                            }
                        })
                    }).fail(function() {
                        alert('����ʧ��')
                        $('.saveClick').attr('disabled', false);
                    })
                }
                var reloadLen = reloadArr.length;
                var restartLen = restartArr.length;
                var arrCheck = [];
                var zxFlag = ''
                if (restartLen != 0) {
                    arrCheck = restartArr;
                    zxFlag = 'restart'
                } else if (reloadLen != 0) {
                    arrCheck = reloadArr;
                    zxFlag = 'reload'
                }
                var t = null;
                if (arrCheck.length == 0) {
                    alert('û���޸�����')
                    $('.saveClick').attr('disabled', false);
                } else {
                    t = setInterval(function() {
                        if (arrCheck.length == 0) {
                            clearInterval(t);
                            $('.saveClick').attr('disabled', false);
                            if (zxFlag == 'restart') {
                                restart(null, 100)
                            } else if (zxFlag == 'reload') {
                                reload()
                            }
                        }
                    }, 200)
                }


            })

            function toIP(id) { //inputתip
                var ip = '';
                $(id).each(function(e, i) {
                    var value = $(this).val().replace(/\s+/g, "")
                    if (value == '') {
                        ip += 'error' + '.';
                        $(this).css('border', '1px solid red')
                    } else {
                        ip += value + '.';
                        $(this).css('border', '1px solid #e6e6e6')
                    }

                })
                return ip.substring(0, ip.length - 1);
            }

            $('.selectBox .selectBtn').click(function(e) { //������
                var ulElemnt = $(this).parent().find('ul');

                var zIndex = ulElemnt.parent().css('zIndex') - 0 + 1;
                $('.selectBox  ul').hide()
                if (ulElemnt.css("display") == 'block') {

                    ulElemnt.parent().find('.selectBtn').css('zIndex', zIndex)
                } else {

                    ulElemnt.show()
                    ulElemnt.parent().find('.selectBtn').css('zIndex', zIndex)

                    zIndex = 2000;
                    $('.layui-body').append('<div class="mask" style="z-index: ' + zIndex + ';"></div>');
                    $('.layui-body').on('click', '.mask', maskClick)
                    $('.layui-side-scroll').on('click', maskClick)
                }
            });
            $('.selectBox').on('click', 'li', function() { //������
                $(this).html();
                var button = $(this).parent().parent().find('.selectBtn');
                var ulElemnt = $(this).parent();
                var val = $(this).html();
                button.html(val);
                ulElemnt.hide();
                $('.layui-body').off('click', '.mask', maskClick)
                $('.layui-side-scroll').off('click', maskClick)
                $('.mask').remove();
                $('.selectBtn').css('zIndex', 2001)
            });

            function maskClick() { //�ɰ�
                $('.selectBox  ul').hide()
                $('.mask').remove();
                $('.selectBtn').css('zIndex', 2001)
            }

            var cp = ColorPicker(
                document.getElementById('slider'),
                document.getElementById('picker'),
                function(hex, hsv, rgb) {

                    $('#hex').html(hex)
                    $('#colorView').css('background', hex)
                });
            var colorBtn = null;
            $('.layui-body').on('click', '.colorBtn', function(e, i) {
                colorBtn = {
                    dom: this,
                    index: $(this).attr('data-index') - 0
                };
                $('#colorChoose').hide();
                $('#colorChooseBox').show();
                var color = $(this).html();
                i = $(this).attr('data-index');
                setTimeout(function() {
                    $('#colorChoose').show();
                }, 100)
                $('#hex').html(color);
                $('#colorView').css('background', color);
                $('#colorBtnCancel').attr('cancelColor', color);
                cp.setHex(color);
            })
            $('#colorBtnSure').click(function() {
                var color = $('#hex').html()
                $(colorBtn.dom).html(color);
                $(colorBtn.dom).css('background', color);
                switch ($('.layui-this a').attr('changefor')) {
                    case 'advancedSetupBox':
                        choosed[choose_i].setting[colorBtn.index].bg = color;
                        SHOW_FIELDSFlag = true;
                        break
                    case 'alarmSetupBox':
                        break;
                }
                $('#colorChooseBox').hide();
            })
            $('#colorBtnCancel').click(function() {
                colorBtn = null;
                $('#colorChooseBox').hide();
            });
            /*-----------------------��������---------------------*/
            /*-----------------------��������---------------------*/
            $('#timeToger').click(function() { //ͬ��ʱ��
                $('#timeToger').attr('disabled', true)
                $().mkAjax({ //�ο�����Ľӿ�
                    url: '/LB_FORM',
                    type: 'post',
                    data: {
                        LB_SYS_DATE: $().getTime({
                            time: null,
                            style: 'yyyy-MM-dd hh:mm:ss' //
                        })
                    }
                }).then(function(res) {
                    $('#timeToger').attr('disabled', false)
                    reload()
                })
            })

            function goChange() {
                var tabLi = document.querySelectorAll('.layui-nav a');
                tabLi[5].click();
                tabLi[4].parentNode.classList.add('layui-nav-itemed');
            }
            /*-----------------------��������---------------------*/
            /*-----------------------��ַ����---------------------*/
            $('#retry').click(function() {
                $('.connectBtn').trigger("click");
            })
            $('.connectBtn').click(function() {
                // $(".table").hide();
                $('.connectionTestTip').hide();
                var _this = this;
                $(_this).attr('disabled', true);
                $('.connecting').show();

                $().mkAjax({ //�ο�����Ľӿ�
                    url: '/lb_net_test_state.htm',
                    type: 'GET',
                    data: {}
                }).then(function(res) {
                    $('.connecting').hide();
                    $('.connectSuccess').show();
                    // $('.table').show();
                    $(_this).attr('disabled', false);
                    var pingResult = res.split("|"); //��ȡping��Ľ��
                    for (var i = 0; i < pingResult.length; i++) {
                        if (pingResult[i] >= 0) {
                            $(".time").eq(i).html(pingResult[i] + "ms");
                            $(".result").eq(i).addClass("success");
                        } else {
                            $(".result").eq(i).addClass("fail");
                        }
                        console.log($('.time').eq(i))
                    }
                }).fail(function(err) {
                    $('.connecting').hide();
                    $('.connectError').show();
                    $(_this).attr('disabled', false);
                })
            })
            $("#closeTable").click(function() {
                $(".table").hide();
                $('.connectionTestTip').hide();
            });

            $('.maxLenth3').bind("input propertychange", function(event) {
                var val = $(this).val();
                if (val.length > 3) {
                    $(this).val(val.substring(0, 3))
                    if ($(this).next()[0]) { //ǰ������ַ
                        $(this).blur();
                        $(this).next().next().focus();
                    }
                } else {

                }
            });
            /*-----------------------��ַ����---------------------*/
            /*-----------------------�߼�����---------------------*/
            $('.toChoose').on('dblclick', 'li', function(e) {
                var index = e.currentTarget.dataset.no - 0;
                var text = toChoose[index];
                SHOW_FIELDSFlag = true;
                toChoose.splice(index, 1);
                choosed.push(text);
                dataInit();

            })
            $('.choosed').on('dblclick', 'li', function(e) {
                var index = e.currentTarget.dataset.no - 0;
                var text = choosed[index];
                SHOW_FIELDSFlag = true;
                choosed.splice(index, 1);
                toChoose.push(text);
                dataInit();

            });
            /*-----------------------�߼�����---------------------*/
            /*-----------------------��������---------------------*/
            var fileData = null;
            $('#LB_UPGRADE').change(function(e) {
                $('#startUpdate').attr('disabled', true)
                console.log('ѡȡ���ļ�', e.currentTarget.files[0])
                fileData = e.currentTarget.files[0];
                $('#needSpace').html((fileData.size / 1024 / 1024).toFixed(2))
                if (checkUpgradeFileSize(fileData) && checkUpgradeFile(fileData.name)) {
                    $('#filePath').val('C:/file/' + fileData.name);
                    $('#startUpdate').attr('disabled', false)
                }

            })
            $("#startUpdate").click(function() {
                $("#upLoadBar").show();
                $(".updateFileBox").hide();

                try {
                    var form = new FormData();
                    var fileObj = fileData;
                    var xhr = new XMLHttpRequest();
                    form.append("LB_UPGRADE", fileObj);
                    xhr.open("post", "LB_UPGRADE", true);
                    xhr.upload.addEventListener("progress", progressFunction, false); //  ����������
                    xhr.onload = function() {
                        $().mkAjax({
                            url: "./upload_state.html",
                            type: "get",
                        }).then(function(res) {
                            judgeFileStatus(res.trim(), function() {
                                restart(null, 100); //todo
                            });
                        });
                        $("#upLoadBar").hide();
                        $(".updateFileBox").show();
                    }
                    xhr.send(form);



                    function progressFunction(evt) {
                        if (evt.lengthComputable) {
                            $("#progressBar").attr('max', evt.total)
                            $("#progressBar").val(evt.loaded)
                            $("#percentage").html(Math.round(evt.loaded / evt.total * 100) + "%")
                        }
                    }
                } catch (e) {
                    alert("�������֧�֣�����������");
                }







            });

            function judgeFileStatus(status, success) {
                switch (status) {
                    case 'UPLOAD_STATE_OK':
                        success();
                        break;
                    case 'UPLOAD_STATE_INVALID_NAME':
                        alert("�Ƿ��ļ�����");
                        break;
                    case 'UPLOAD_STATE_ZERO_SIZE':
                        alert("�ļ���СΪ0��");
                        break;
                    case 'UPLOAD_STATE_TOOLARGE_SIZE':
                        alert("�ļ�̫��");
                        break;
                    case 'UPLOAD_STATE_INVALID_FORMAT':
                        alert("�Ƿ��ļ���ʽ��");
                        break;
                    case 'UPLOAD_STATE_INVALID_UPGRADE_TYPE':
                        alert("���������Ͳ���ȷ");
                        break;

                }
            }
            // ��������汾
            function versionCheck(fileName) {
                var isGoodSoftwareVersion = true;
                var isGoodPackage = true;
                var nkVersion = window.parent.setting['coreVersion'];
                if (nkVersion.length >= 19) { // �汾�ж� 2017-07-25 14:41:11
                    var y = parseInt(nkVersion.substr(0, 4), 10);
                    var m = parseInt(nkVersion.substr(5, 2), 10);
                    var d = parseInt(nkVersion.substr(8, 2), 10);
                    if (y > 2011 || (y == 2011 && m > 7) || (y == 2011 && m == 7 && d >= 8)) {
                        var len = fileName.length;
                        isGoodSoftwareVersion = false;
                        isGoodPackage = false;
                        var _index = 0;

                        for (i = len - 8; i > 0; i--) {
                            if (fileName.charAt(i) == '_') _index++;
                            if (_index == 2) { // ��NK�汾
                                vy = parseInt(fileName.substr(i + 1, 4), 10);
                                vm = parseInt(fileName.substr(i + 5, 2), 10);
                                vd = parseInt(fileName.substr(i + 7, 2), 10);
                                if (vy > y || (vy == y && vm > m) || (vy == y && vm == m && vd >= d))
                                    isGoodSoftwareVersion = true;
                            } else if (_index == 3) {
                                package_version = parseInt(fileName.substr(i + 1, 1), 10);
                                if (package_version >= 2)
                                    isGoodPackage = true;
                            }

                        }
                    }
                }

                if (!isGoodSoftwareVersion) {
                    alert("��ѡ���������汾̫�ϣ���ϵͳ��NK�汾��ƥ��!");
                    return false;
                }
                if (!isGoodPackage) {
                    alert("������߰汾̫�ϣ������µĴ���������´��!");
                    return false;
                }
                return true;
            }

            function checkUpgradeFile(name) {
                var fileName = name;
                var suffix = fileName.substring(fileName.length - 7);
                if (suffix == ".lonbon" || confirm("�Ƿ��ļ����������ļ���չ��ͨ��Ϊ.lonbon������ȷ��Ҫ������?\n")) {
                    var warm = "��ȷ��ѡ�������ڱ����������ļ���������ܵ��²���Ԥ�ڵĴ���";
                    if (confirm(warm)) {
                        return versionCheck(fileName);
                    }
                }
                return true;
            }

            function checkUpgradeFileSize(obj) { // ����ļ���С
                var fileSize = 0;
                var isIE = /msie/i.test(navigator.userAgent) && !window.opera;
                if (isIE && !obj.files) {
                    try {
                        var filePath = $('#LB_UPGRADE').val();
                        var fileSystem = new ActiveXObject("Scripting.FileSystemObject");
                        var file = fileSystem.GetFile(filePath);
                        fileSize = file.Size;
                    } catch (e) {
                        return true;
                    }
                } else {
                    fileSize = obj.size;
                }


                if (fileSize > setting['availableSpace'] - 0) {
                    alert("�ڴ�ռ䲻��");
                    return false;
                }
                fileSize = Math.round(fileSize / 1024 * 100) / 100; //��λΪKB
                if (fileSize > 100 * 1024) {
                    alert("���������ܴ���100M");
                    return false;
                }
                return true;
            }
            /*-----------------------��������---------------------*/
            /*-----------------------��������---------------------*/

            function restart(action, time) {
                $("#warning").hide();
                $("#timer").show();
                $('.layui-nav a')[11].click();
                if (action) {
                    $("#tips").html(action);
                }

                if (time) {
                    timeOut = time;
                } else {
                    timeOut = 90;
                }
                $('#reset').attr('disabled', true)
                $().mkAjax({
                    url: '/RESET',
                    type: 'post',
                    data: {
                        RESET: 'NORMAL'
                    }
                }).then(function(res) {

                    var i = timeOut;
                    $('.restartBox').html('���Ժ������������벻Ҫ�رյ�Դ...')
                    $("#reset").html('ʣ��ʱ��' + i + 's');
                    var interval = setInterval(function() {
                        i--;
                        if (i <= 0) {
                            top.location = "./lb_control.html";
                            clearInterval(interval);
                        } else {

                            $("#reset").html('ʣ��ʱ��' + i + 's');
                        }
                    }, 1000)
                }).fail(function() {
                    alert('��������æ,���Ժ��ٴγ���')
                })
            };


            $('#reset').click(function() {
                    restart(null, 60)

                })
                /*-----------------------��������---------------------*/
        })();