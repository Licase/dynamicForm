var advancedSetup = [{
    field_identify: 'care_level',
    setting: [{
            value: "�ؼ�",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "�߼�",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "һ��",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "����",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "����",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        }
    ],
    name: '��������',
    nick: '��',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}, {
    field_identify: 'isolation_name',
    setting: [{
            value: "��ȫ����",
            nick: "ȫ",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "�����",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "������",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        }
    ],
    name: '����',
    nick: '��',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}, {
    field_identify: 'diet_name',
    setting: [{
            value: "��ʳ",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "����ʳ",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "��ʳ",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "��ʳ",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        }
    ],
    name: '��ʳ',
    nick: 'ʳ',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}, {
    field_identify: 'measure_name',
    setting: [{
            value: "��",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        },
        {
            value: "��",
            nick: "��",
            bg: "#ffffff",
            font: "#ffffff",
            border: "#ffffff",
            size: 16
        }
    ],
    name: '����',
    nick: '��',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}, {
    field_identify: 'hypertension',
    setting: [{
        value: "��",
        nick: "��",
        bg: "#ffffff",
        font: "#ffffff",
        border: "#ffffff",
        size: 16
    },
    {
        value: "��",
        nick: "��",
        bg: "#ffffff",
        font: "#ffffff",
        border: "#ffffff",
        size: 16
    }
    ],
    name: '��Ѫѹ',
    nick: '��',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}, {
    field_identify: 'allergy_name',
    setting: [{
        value: "��",
        nick: "��",
        bg: "#ffffff",
        font: "#ffffff",
        border: "#ffffff",
        size: 16
    }  
    ],
    name: '����',
    nick: '��',
    bg: "#ffffff",
    font: "#ffffff",
    border: "#ffffff",
    size: 16
}]