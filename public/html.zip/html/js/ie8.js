// ����getElementsByClassName
if (!('getElementsByClassName' in document)) {
    function getElementsByClassName (classList) {
      if (typeof classList !== 'string') throw TypeError('the type of classList is error')
      // ��ȡ��Ԫ��
      var parent = this
      // ��ȡ��Ӧ��Ԫ��
      var child = parent.getElementsByTagName('*')
      var nodeList = []
      // ���classList��ÿ������ ���ǰ��ո� �Լ���������֮��ո�ֹһ������
      var classAttr = classList.replace(/^\s+|\s+$/g, '').split(/\s+/)
      for (var j = 0, len = child.length; j < len; j++) {
        var element = child[j]
        for (var i = 0, claLen = classAttr.length; i < claLen; i++) {
          var className = classAttr[i]
          if (element.className.search(new RegExp('(\\s+)?'+className+'(\\s+)?')) === -1) break
        }
        if (i === claLen) nodeList.push(element)
      }
      return nodeList
    }
    // ����ie5�����ϵ�document��getElementsByClassName�ӿ�
    document.getElementsByClassName = getElementsByClassName
    // ����ie8�����ϵ�getElementsByClassName�ӿ�
    window.Element.prototype.getElementsByClassName = getElementsByClassName
  }

//   if (!("classList" in document.documentElement)) {
//     Object.defineProperty(Element.prototype, 'classList', {
//         get: function() {
//             var self = this;
//             function update(fn) {
//                 return function(value) {
//                     var classes = self.className.split(/\s+/g),
//                         index = classes.indexOf(value);

//                     fn(classes, index, value);
//                     self.className = classes.join(" ");
//                 }
//             }

//             return {
//                 add: update(function(classes, index, value) {
//                     if (!~index) classes.push(value);
//                 }),

//                 remove: update(function(classes, index) {
//                     if (~index) classes.splice(index, 1);
//                 }),

//                 toggle: update(function(classes, index, value) {
//                     if (~index)
//                         classes.splice(index, 1);
//                     else
//                         classes.push(value);
//                 }),

//                 contains: function(value) {
//                     return !!~self.className.split(/\s+/g).indexOf(value);
//                 },

//                 item: function(i) {
//                     return self.className.split(/\s+/g)[i] || null;
//                 }
//             };
//         }
//     });
// }
//��������IndexOf����
if (!Array.prototype.indexOf){
    Array.prototype.indexOf = function(elt /*, from*/){
      var len = this.length >>> 0;
  
      var from = Number(arguments[1]) || 0;
      from = (from < 0)
           ? Math.ceil(from)
           : Math.floor(from);
      if (from < 0)
        from += len;
  
      for (; from < len; from++){
        if (from in this && this[from] === elt)
          return from;
      }
      return -1;
    };
}
//����
if ( !Array.prototype.forEach ) {
    Array.prototype.forEach = function forEach( callback, thisArg ) {
      var T, k;
      if ( this == null ) {
        throw new TypeError( "this is null or not defined" );
      }
      var O = Object(this);
      var len = O.length >>> 0; 
      if ( typeof callback !== "function" ) {
        throw new TypeError( callback + " is not a function" );
      }
      if ( arguments.length > 1 ) {
        T = thisArg;
      }
      k = 0;
      while( k < len ) {
        var kValue;
        if ( k in O ) {
          kValue = O[ k ];
          callback.call( T, kValue, k, O );
        }
        k++;
      }
    };
  }
   //�ж�IE7\8 �����Լ��
   var Event = {};
   Event.addEvents = function(target,eventType,handle){
       if(document.addEventListener){
           Event.addEvents = function(target,eventType,handle){
               target.addEventListener(eventType,handle,false);
           };
       }else{
           Event.addEvents = function(target,eventType,handle){
               target.attachEvent('on'+eventType,function(){
                   handle.call(target,arguments);
               });
           };
       };
       Event.addEvents(target,eventType,handle);
   };

 function browserVersion ()   {
    var userAgent = navigator.userAgent,
        rMsie = /(msie\s|trident.*rv:)([\w.]+)/,
        rFirefox = /(firefox)\/([\w.]+)/,
        rOpera = /(opera).+version\/([\w.]+)/,
        rChrome = /(chrome)\/([\w.]+)/,
        rSafari = /version\/([\w.]+).*(safari)/;
    var browser;
    var version;
    var ua = userAgent.toLowerCase();

    function uaMatch(ua) {
        var match = rMsie.exec(ua);
        if (match != null) {
            return {
                browser: 'IE',
                version: match[2] || '0'
            };
        }
        var match = rFirefox.exec(ua);
        if (match != null) {
            return {
                browser: match[1] || '',
                version: match[2] || '0'
            };
        }
        var match = rOpera.exec(ua);
        if (match != null) {
            return {
                browser: match[1] || '',
                version: match[2] || '0'
            };
        }
        var match = rChrome.exec(ua);
        if (match != null) {
            return {
                browser: match[1] || '',
                version: match[2] || '0'
            };
        }
        var match = rSafari.exec(ua);
        if (match != null) {
            return {
                browser: match[2] || '',
                version: match[1] || '0'
            };
        }
        if (match != null) {
            return {
                browser: '',
                version: '0'
            };
        }
    }
    var browserMatch = uaMatch(userAgent.toLowerCase());
    if (browserMatch.browser) {
        browser = browserMatch.browser;
        version = browserMatch.version;
    }
    console.log(browser + version)
    return browser + version;
}

Date.prototype.format = function (format) {
    var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ?
                date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
    }
    return format;
}